#!/usr/bin/env python3
# -*- coding: utf-8 -*-
 
import rospy
import tf
import os
from std_msgs.msg import Float32MultiArray
from geometry_msgs.msg import Vector3Stamped
from sensor_msgs.msg import NavSatFix, Imu 
from nav_msgs.msg import Odometry
from pyproj import Proj

class GPSIMUParser:
    def __init__(self):
        rospy.init_node('GPS_IMU_parser', anonymous=True)
        self.gps_sub = rospy.Subscriber("/ublox_gps/fix", NavSatFix, self.navsat_callback)
        self.imu_sub = rospy.Subscriber("/imu/data", Imu, self.imu_callback)
        self.odom_pub = rospy.Publisher('/odom', Odometry, queue_size=1)
        self.init_flag = False
        self.x, self.y = None, None
        self.is_imu = False
        self.is_gps = False
        self.lat = 0.0
        self.lon = 0.0
        self.proj_UTM = Proj(proj='utm', zone=52, ellps='WGS84', preserve_units=False)
        #self.e_o = 922947.3277220834 # TUNING
        #self.n_o = 1931115.6237988032
        self.e_o = 0.0 # TUNING
        self.n_o = 0.0
        
        self.odom_msg = Odometry()
        self.odom_msg.header.frame_id = 'odom'
        self.odom_msg.child_frame_id = 'base_link'

        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            os.system('clear')
            if self.is_imu and self.is_gps:
                self.convertLL2UTM()
                self.odom_pub.publish(self.odom_msg)
                print("odom_msg is now being published at '/odom' topic!\n")
                print('-----------------[ odom_msg ]---------------------')
                print(self.odom_msg.pose.pose)

            if not self.is_imu:
                print("[1] Can't subscribe to '/imu' topic... \n    Please check your IMU sensor connection.")
            if not self.is_gps:
                print("[2] Can't subscribe to '/gps' topic... \n    Please check your GPS sensor connection.")
            
            self.is_gps = self.is_imu = False
            rate.sleep()

    def navsat_callback(self, gps_msg):
        self.lat = gps_msg.latitude
        self.lon = gps_msg.longitude
        self.is_gps = True

    def convertLL2UTM(self):
        # 위도, 경도를 UTM 좌표로 변환
        self.x, self.y = self.proj_UTM(self.lon, self.lat)
        
        if self.init_flag == False:
            self.e_o = self.x
            self.n_o = self.y
            self.init_flag = True
        self.odom_msg.header.stamp = rospy.get_rostime()
        self.odom_msg.pose.pose.position.x = self.x - self.e_o
        self.odom_msg.pose.pose.position.y = self.y - self.n_o
        self.odom_msg.pose.pose.position.z = 0.0

    def imu_callback(self, data):
        # IMU 데이터를 바탕으로 오리엔테이션 업데이트
        self.odom_msg.pose.pose.orientation.x = data.orientation.x
        self.odom_msg.pose.pose.orientation.y = data.orientation.y
        self.odom_msg.pose.pose.orientation.z = data.orientation.z
        self.odom_msg.pose.pose.orientation.w = data.orientation.w

        self.is_imu = True

if __name__ == '__main__':
    try:
        GPS_IMU_parser = GPSIMUParser()
    except rospy.ROSInterruptException:
        pass
