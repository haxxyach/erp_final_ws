#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import rospy
import rospkg
from morai_msgs.msg import EgoVehicleStatus
from math import sqrt, pow
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
import tf
import sys  # 명령줄 인자를 받기 위해 sys 모듈 추가
from erp.msg import erpStatusMsg
from sensor_msgs.msg import NavSatFix

class Test:

    def __init__(self):
        rospy.init_node('path_maker', anonymous=True)
        #rospy.Subscriber("/erp42_status", erpStatusMsg, self.erp_callback)
        #rospy.Subscriber("/Ego_topic", EgoVehicleStatus, self.status_callback)
        # vel, steer 
        self.global_path_pub = rospy.Publisher('/global_path', Path, queue_size=1)
        self.gps_sub = rospy.Subscriber("/ublox_gps/fix", NavSatFix, self.navsat_callback)
        
        self.is_status = False
        self.prev_x = 0
        self.prev_y = 0

        self.path_msg = Path()  # 경로 메시지 초기화
        self.path_msg.header.frame_id = "map"  # frame_id 설정

        self.speed = 0
        self.steer = 0

        # 명령줄 인자로 파일 경로를 받음. 없을 경우 기본 경로로 설정
        if len(sys.argv) > 1:
            self.file_path = sys.argv[1]  # 명령줄 인자로 파일 경로 받기
        else:
            self.file_path = "/home/unita/Desktop/test_kcity.txt"  # 기본 경로 설정

        self.f = open(self.file_path, 'w')

        rate = rospy.Rate(30)
        while not rospy.is_shutdown():
            if self.is_status:
                self.path_make()
            self.global_path_pub.publish(self.path_msg)  # 경로 퍼블리시
            rate.sleep()

        self.f.close()


    def path_make(self):
        x = self.status_msg.position.x
        y = self.status_msg.position.y
        z = self.status_msg.position.z
        distance = sqrt(pow(x - self.prev_x, 2) + pow(y - self.prev_y, 2))
        if distance > 0.01:
            # 파일에 기록
            data = '{0}\t{1}\t{2}\n'.format(x, y, z)
            self.f.write(data)

            # 새로운 포인트를 경로에 추가
            pose = PoseStamped()
            pose.header.frame_id = "map"
            pose.pose.position.x = x
            pose.pose.position.y = y
            pose.pose.position.z = z
            pose.pose.orientation.w = 1.0  # 기본 회전 값

            self.path_msg.poses.append(pose)  # 경로에 새로운 포즈 추가
            self.prev_x = x
            self.prev_y = y
            print(x, y)

    def status_callback(self, msg):  # Vehicle Status Subscriber
        self.is_status = True
        self.status_msg = msg
        br = tf.TransformBroadcaster()
        br.sendTransform((self.status_msg.position.x, self.status_msg.position.y, self.status_msg.position.z),
                         tf.transformations.quaternion_from_euler(0, 0, (self.status_msg.heading) / 180 * 3.141592),
                         rospy.Time.now(),
                         "gps",
                         "map")


if __name__ == '__main__':
    try:
        test_track = Test()
    except rospy.ROSInterruptException:
        pass
