#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from morai_msgs.msg import CtrlCmd
from std_msgs.msg import Int32
import serial

port = "/dev/ttyUSB0"
count_alive = 0

# 고정값 설정
S = 0x53
T = 0x54
X = 0x58
AorM = 0x01
ESTOP = 0x00
GEAR = 0x00
SPEED0 = 0x00
SPEED1 = 0x00
STEER0 = 0x02
STEER1 = 0x02
BRAKE = 0x01
ALIVE = 0
ETX0 = 0x0d
ETX1 = 0x0a

def GetAorM():
    return 0x01

def GetESTOP():
    return 0x00

def GetGEAR(gear):
    return gear

def GetSPEED(speed):
    global SPEED0, SPEED1
    SPEED0 = 0x00
    SPEED1 = speed
    return SPEED0, SPEED1

def GetSTEER(steer):
    steer = steer * 71
    steer_max = 0b0000011111010000
    steer_0 = 0b0000000000000000
    steer_min = 0b1111100000110000

    if steer >= 0:
        angle = int(steer)
        STEER = steer_0 + angle
    else:
        angle = int(-steer)
        angle = 2000 - angle
        STEER = steer_min + angle

    STEER0 = (STEER & 0b1111111100000000) >> 8
    STEER1 = STEER & 0b0000000011111111

    return STEER0, STEER1

def GetBRAKE(brake):
    return brake

def Send_to_ERP42(gear, speed, steer, brake):
    global S, T, X, AorM, ESTOP, GEAR, SPEED0, SPEED1, STEER0, STEER1, BRAKE, ALIVE, ETX0, ETX1, count_alive

    count_alive = (count_alive + 1) % 0xff
    ALIVE = count_alive

    AorM = GetAorM()
    ESTOP = GetESTOP()
    GEAR = GetGEAR(gear)
    SPEED0, SPEED1 = GetSPEED(speed)
    STEER0, STEER1 = GetSTEER(steer)
    BRAKE = GetBRAKE(brake)

    vals = [S, T, X, AorM, ESTOP, GEAR, SPEED0, SPEED1, STEER0, STEER1, BRAKE, ALIVE, ETX0, ETX1]
    packet = bytes(vals)
    ser.write(packet)

def Read_from_ERP42():
    global Packet
    Packet = ser.read(18)
    if len(Packet) == 18:
        cur_ENC = Packet[11]
        return cur_ENC
    else:
        return 0  # Default value if packet is not of expected length

def ctrl_cmd_callback(data):
    gear = 0  # 기본값
    speed = int(data.velocity)  # 실제 사용 시 적절한 변환 필요
    steer = -data.steering *180/3.14 # 수신된 조향 각도
    brake = 0  # 기본값, 필요 시 데이터에서 추출

    # 디버깅 출력
    print(f"Received steering command: {steer}")
    print(f"Received speed command: {speed}")

    # ERP42로 명령 전송
    Send_to_ERP42(gear, speed, steer, brake)

if __name__ == '__main__':
    rospy.init_node('serial_node')

    pub_encoder = rospy.Publisher('ENCODER_DATA', Int32, queue_size=10)
    rospy.Subscriber('ctrl_cmd_0', CtrlCmd, ctrl_cmd_callback)

    rate = rospy.Rate(20)

    port = rospy.get_param("~CTRL_PORT", default=port)
    ser = serial.Serial(port, baudrate=115200, timeout=1)

    try:
        while ser.isOpen() and not rospy.is_shutdown():
            # Read from Controller
            ENC = Read_from_ERP42()
            pub_encoder.publish(ENC)

            rate.sleep()

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        ser.close()